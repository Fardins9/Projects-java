import Data.*;
import java.io.*;
class Item{
    String name;
    float price;
    int quantity;
    float amount;
    Item(String name,float price,int quantity){
        this.name=name;
        this.price=price;
        this.quantity=quantity;
        amount=price*quantity;
    }
}
class Bill{
    static Date date = new Date(03,01,2022);
    ProductDetails obj1;
    Item it[] = new Item[10]; 
    Product p1 = new Product();
    int i=0;
    float total=0;
    void addPurchase(int id, int qty){
        obj1=p1.getProduct(id);
        it[i] = new Item(obj1.pname, obj1.price, qty) ;
        i++;
    }
    void printBill(String name, String no, int id, String mode){
        System.out.println("\n\n\t\tSmall Baazar\n \t College road, Nashik 422001\n  \t     no.: +91-7219326765\n  \t customer care: in@mrdiy.com\n\t\tGSTIN: 27AAI69\n\t\t--Tax Invoice--");
        System.out.println("---------------------------------------------------");
        System.out.println("\t\t-Customer Details- ");
        System.out.println("Name: "+name);
        System.out.println("No.: "+no);
        System.out.println("Customer id: "+id);
        System.out.println("---------------------------------------------------");
        System.out.println("Product\t | Price \t | Quantity \t | Amount");
        System.out.println("---------------------------------------------------");
        for(int j=0;j<i;j++){
            System.out.println(it[j].name+"\t | "+it[j].price+"$\t | "+it[j].quantity+"\t\t | "+it[j].amount);
            total+=it[j].amount;
        }
        System.out.println("---------------------------------------------------");
        System.out.println("Total-\t "+total+" $");
        System.out.println("Mode of payment: "+mode);
        System.out.print("Date of purchase: ");
        date.showDate();
        System.out.println("\t...Thanks for shopping, visit again...\n\n");
    }
    
}
public class Billing {
    //CustomerDetails obj;
    public static void main(String[] args) throws IOException {
        Customer c = new Customer();
        Product p = new Product();
        BufferedReader br =  new BufferedReader(new InputStreamReader(System.in));
        boolean cond = true;
        CustomerDetails obj;
        int id;
        do {
            System.out.println("\n\t--- Menu---");
            System.out.println("1.Billing\n2.Update Customer\n3.Add new product\n4.Update a product\n5.Exit");
            System.out.print("Enter the task: ");
            int ch = Integer.parseInt(br.readLine());
            switch (ch) {
                case 1:System.out.print("\n1.Existing customer\n2.New customer\nSelect option: ");
                        int tp = Integer.parseInt(br.readLine()); //Type of customer
                        if(tp==2){
                            System.out.println("\nEnter customer details");
                            System.out.print("Name: ");
                            String name = br.readLine();
                            System.out.print("Contact number: ");
                            String no = br.readLine();
                            obj = c.addCustomer(name,no); // object if new Customer
                            break;
                        }
                        System.out.print("\nEnter the Customer id: ");
                        obj = c.getCustomer(Integer.parseInt(br.readLine())); // Object if old customer by searching

                        Bill b = new Bill();
                        boolean purchase = true;
                        System.out.println("\nEnter the purchase details");
                        do{
                            System.out.print("Enter the product id , press 0 to generate bill: ");
                            id = Integer.parseInt(br.readLine());
                            if(id==0){
                                System.out.print("Enter mode of payment: ");
                                String mode = br.readLine();
                                b.printBill(obj.cname,obj.contactNo,obj.cid,mode);
                                purchase=false;
                            }
                            else{
                                System.out.print("Enter the Quantity: ");
                                int qty = Integer.parseInt(br.readLine());
                                b.addPurchase(id, qty);
                            }
                        }while(purchase==true);

                        break;
                case 2:System.out.print("\nEnter customer id of customer to be updated: ");
                        id = Integer.parseInt(br.readLine());
                        System.out.print("Enter the new contact number of " + c.getCustomer(id).cname + " : ");
                        String no = br.readLine();
                        c.updateContact(id, no);  
                        break;
                case 3:System.out.println("\nEnter the new product details");
                        System.out.print("Name: ");
                        String name = br.readLine();
                        System.out.print("Description: ");
                        String description = br.readLine();
                        System.out.print("Price: ");
                        float price = Integer.parseInt(br.readLine());
                        p.addProduct(name, description, price);
                        break;
                case 4:System.out.print("\nEnter the product id: "); 
                        id = Integer.parseInt(br.readLine());
                        System.out.print("Enter the new price of " + p.getProduct(id).pname + " : ");
                        price = Integer.parseInt(br.readLine());
                        p.updatePrice(id, price);
                        break;
                case 5: cond=false;
                        System.out.println("Thanks for using our billing System.");
                        break;
                default:
                    System.out.println("Please enter a valid option");
                    break;
            }
        } while (cond==true);


    }
    
}