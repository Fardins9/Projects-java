package Data;
public class ProductDetails{
    public int pid;
    public String pname;
    public String description;
    public float price;
    //MyDate manufacturingDate;
    //Constructor sets the details of product
    public ProductDetails(int pid,String pname,String description,float price){
        this.pid=pid;
        this.pname=pname;
        this.description=description;
        this.price=price;
    }
}