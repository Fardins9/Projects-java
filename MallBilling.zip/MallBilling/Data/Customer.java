package Data;
import Data.CustomerDetails;
public class Customer{
    public CustomerDetails cd[] = new CustomerDetails[10];
    public int count;
    public int idCount;
    //old customers having details 
    public Customer(){
        cd[0]= new CustomerDetails(500,"Isha rawat","+91-9631245648");
        cd[1] = new CustomerDetails(501,"Shlok Shriwastav","+91-8087334596");
        cd[2] = new CustomerDetails(502,"Fardin Shaikh","+91-7219326765");
        cd[3] = new CustomerDetails(503,"Mahima gandhi","+91-9421036542");
        cd[4] = new CustomerDetails(504, "Jaya Mahajan", "+91-7631254789");
        cd[5] = new CustomerDetails(505, "Shrusti Patil", "+91-8523697536");
        count = 5; //For index of array of object
        idCount = 505; // For auto increment of id
    }
    // If customer is a old customer then this method should be used
    public CustomerDetails getCustomer(int id){
        int k = 0;
        for(int i=0; i<10; i++){
            if(cd[i].cid==id){
                k=i;
                break;
            }
        }
        return cd[k];
    }
    //If customer is new use this method
    public CustomerDetails addCustomer(String cname,String contactNo){
        count+=1;
        idCount+=1;
        cd[count] = new CustomerDetails(idCount, cname, contactNo);
        System.out.println("Customer added succefully for id "+idCount);
        return cd[count];
    }
    //when a purchase is made this method should be called to update the number of purchase
    public void updateContact(int id, String no){
        getCustomer(id).contactNo = no;
        System.out.println("Information Updated Successfully for "+getCustomer(id).cname);
    }
}