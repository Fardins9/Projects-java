package Data;
//Class as data type / Abstract data type

import java.io.*;
public class Date{
	public int dd,mm,yy;
	public Date(int dd, int mm, int yy){
		this.dd=dd;
		this.mm=mm;
		this.yy=yy;
	}
	public void showDate(){
		System.out.println(dd+"/"+mm+"/"+yy);
	}
	public boolean isValidDate(){
		if(yy>1900 && yy<2023){
			if(mm>=1 && mm<=12){
                if(mm==1 || mm==3||mm==5||mm==7||mm==8||mm==10||mm==12){
                    if(dd>=1 && dd<=31)
                        return true;
                    else
                        return false;
                }
            
                else if(mm== 4|| mm==6||mm==9||mm==11){
                    if(dd>=1 && dd<=30)
                        return true;
                    else
                        return false;
                }
                else if(mm==2 && yy%4==0){
                    if(dd>=1 && dd<=29)
                        return true;
                    else
                        return false;
                }
                else{
                    if(dd>=1 && dd<=28)
                        return true;
                    else{
                    System.out.println("Please enter a valid Date !!");
                    return false;
                    }
                }  
            }      
            else{
            System.out.println("Please enter a valid month !!");
            return false;
            }
        }        
		else{
			System.out.println("Please enter a valid year !!");
			return false;
		}
	}
}
/*class Employee{
	String ename;
	Date dob;
	Date doj;
	int eid;
	Employee()throws IOException{
		System.out.print("Enter the employee name: ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		this.ename = br.readLine();
		do{
			System.out.print("Enter the Date of birth \nEnter day: ");
			int dd = Integer.parseInt(br.readLine());
			System.out.print("Enter month: ");
			int mm = Integer.parseInt(br.readLine());
			System.out.print("Enter year: ");
			int yy = Integer.parseInt(br.readLine());
			this.dob = new Date(dd,mm,yy);
		}while(dob.isValidDate() == false);
		
	}
	void showDetails(){
		System.out.println("\nName of employee: " + ename);
		System.out.print("Date of birth: ");
		dob.showDate();
	}
}
*/


// public class MyDate{
	
// 	public static void main(String args[])throws IOException{
// 		Employee e1 = new Employee();
// 		Employee e2 = new Employee();
// 		e1.showDetails();
// 		e2.showDetails();
// 	}
// }