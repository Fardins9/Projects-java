package Data;
import Data.*;
//This class is for creation for various objects for the no. products 
public class Product{
    public ProductDetails pd[] = new ProductDetails[10];
    public int pcount;
    public int pidCount;
    public Product(){
        pd[0]=new ProductDetails(100, "Maggie", "This is a world class maggiee in 2 min", 12);
        pd[1]=new ProductDetails(101, "Noodles", "Hakka noodles", 100);
        pd[2]=new ProductDetails(102, "Oreo", "Medium size oreo",10);
        pd[3]=new ProductDetails(103,"Pepsi","Ghoot me swag hai",50);
        pd[4]=new ProductDetails(104,"Badam","original badam",900);
        pd[5]=new ProductDetails(105,"Pasta","Good pasta",40);
        pcount=5;
        pidCount=105;
    }
    public ProductDetails getProduct(int id){
        int k = 0;
        for(int i=0; i<10; i++){
            if(pd[i].pid==id){
                k=i;
                break;
            }
        }
        return pd[k];
    }
    public void addProduct(String pname,String description,float price){
        pcount+=1;
        pidCount+=1;
        pd[pcount]=new ProductDetails(pidCount, pname, description, price);
        System.out.println("New product added successfully with id "+pidCount);
    }
    public void updatePrice(int id,float price){
        getProduct(id).price=price;
        System.out.println("Price updated successfully for "+ getProduct(id).pname);
    }
}