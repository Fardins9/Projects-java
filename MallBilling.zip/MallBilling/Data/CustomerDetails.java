package Data;
//Contains Details of all previous customers
public class CustomerDetails{
    public int cid;
    public String cname;
    public String contactNo;
    public CustomerDetails(int cid,String cname,String contactNo){
        this.cid=cid;
        this.cname=cname;
        this.contactNo=contactNo;
    }
}
