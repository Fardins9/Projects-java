//  Write a java program to create a package "SY" which has a class SYMarks (members- ComputerTotal, mathsTotal, ElectronicsTotal). 
// Create another package TY which has a class TYMarks (members- Theory, Practicals).Create n object of student class (having rollNumber , name, SYmarks and TYMarks). 
// Add the marks of SY and TY computer subjects and calculate the Grade ('A' for >=70,'B' for >=60, 'C' for >=50, pass class for >=40 else 'FAIL') and display the result of the students in proper format.


import SY.*;
import TY.*;
import java.io.*;

class Student {
	int rollNo;
	String name;
	String grade;
	
	Student() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("\nEnter the roll no: ");
		this.rollNo = Integer.parseInt(br.readLine());
		System.out.print("Enter the name: ");
		this.name = br.readLine();
		
	}

	void calGrade(SYMarks obj, TYMarks obj2) throws IOException {

		int avg = (obj2.theory+obj2.practical+obj.computerTotal+obj.mathsTotal+obj.electronicsTotal)/5;
		if (avg>=70){
			grade = "A";
		}
		else if (avg>=60){
			grade = "B";
		}
		else if (avg>=50){
			grade = "c";
		}
		else if (avg>=40){
			grade = "PASS";
		}
		else{
			grade = "FAIL";
		}
	}

	void printGrade(){
		System.out.println("\nRoll number: " + rollNo);
		System.out.println("Name: "+name);
		System.out.println("Grade: " + grade);
	}
}

public class Assignment25{
	public static void main(String args[]) throws IOException {
		Student s[] = new Student[3];
		SYMarks sm[] = new SYMarks[3];
		TYMarks tm[] = new TYMarks[3];
		for (int i=0;i<3;i++){
			s[i] = new Student();
			sm[i] = new SYMarks();
			tm[i] = new TYMarks();
		}
		for (int i=0; i<3; i++){
			s[i].calGrade(sm[i],tm[i]);
			s[i].printGrade();
		}
	}
}