package SY;
import java.io.*;
public class SYMarks{
	public int computerTotal;
	public int mathsTotal;
	public int electronicsTotal;
	
	public SYMarks() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Enter the marks in computer: ");
		computerTotal = Integer.parseInt(br.readLine());
		System.out.print("Maths: ");
		mathsTotal = Integer.parseInt(br.readLine());
		System.out.print("Electronics: ");
		electronicsTotal = Integer.parseInt(br.readLine());
	}
}

