package TY;
import java.io.*;
public class TYMarks{
	public int theory;
	public int practical;
	
	public TYMarks() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Enter the marks in theory in TY: ");
		this.theory = Integer.parseInt(br.readLine());
		System.out.print("Enter the marks in practical in TY: ");
		this.practical = Integer.parseInt(br.readLine());
	}
}